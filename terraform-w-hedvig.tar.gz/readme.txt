Terraform with Hedvig Provider instructions

1. Extract this tarball in the desired directory (such as /home/username)
2. Grab the appropriate zip file from https://www.terraform.io/downloads.html
3. Unzip the zip file in the same directory as the tarball, and make sure
    that directory is in your PATH.
3. Run initialization by running the following from that directory:
    ./terraform init -plugin-dir=/home/username
4. Modify the config.tf file with desired settings
5. Run plan to see what will be created on your cluster:
    ./terraform plan
6. Run apply to create your desired set-up:
    ./terraform apply
7. Repeat 4-6 as necessary
